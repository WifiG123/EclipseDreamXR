package com.eclipsedream.xr;

interface IShellService {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
    String installApk(in ParcelFileDescriptor pfd, long size) = 2;
}
