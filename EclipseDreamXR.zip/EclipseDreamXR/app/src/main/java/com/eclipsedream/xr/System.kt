package com.eclipsedream.xr

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.*
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.webkit.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

/* ---------------- Navegador ---------------- */
fun normalize(v: String): String {
    val s = v.trim()
    return when {
        s.startsWith("http://") || s.startsWith("https://") -> s
        s.contains(".") && !s.contains(" ") -> "https://$s"
        else -> "https://www.google.com/search?q=" + Uri.encode(s)
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(start: String) {
    var url by remember { mutableStateOf(start) }
    var wv by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableFloatStateOf(0f) }
    BackHandler(wv?.canGoBack() == true) { wv?.goBack() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundBtn("‹") { wv?.goBack() }; RoundBtn("›") { wv?.goForward() }; RoundBtn("⟳") { wv?.reload() }
            OutlinedTextField(
                url, { url = it }, singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { wv?.loadUrl(normalize(url)) })
            )
            RoundBtn("🏠") { wv?.loadUrl(start) }
        }
        if (loading > 0f && loading < 1f) LinearProgressIndicator(progress = { loading }, modifier = Modifier.fillMaxWidth())
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true; settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.useWideViewPort = true; settings.loadWithOverviewMode = true
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() { override fun onPageFinished(v: WebView?, u: String?) { url = u ?: url } }
                    webChromeClient = object : WebChromeClient() { override fun onProgressChanged(v: WebView?, p: Int) { loading = p / 100f } }
                    loadUrl(start); wv = this
                }
            },
            onRelease = { it.destroy() }, modifier = Modifier.fillMaxSize()
        )
    }
}

/* ---------------- Configurações ---------------- */
@Composable
fun SettingsScreen() {
    val c = LocalContext.current
    var tab by remember { mutableStateOf("Geral") }
    Row(Modifier.fillMaxSize()) {
        SideNav(listOf("Geral", "Aparência", "Guardian", "Dispositivo", "Sobre"), tab) { tab = it }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(22.dp)) {
            when (tab) {
                "Geral" -> {
                    H("Geral")
                    OutlinedTextField(AppState.name, { AppState.name = it.take(20); AppState.save() }, label = { Text("Nome do perfil") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    ToggleRow("Apresentação ao abrir", "Animação do eclipse no início", AppState.bootAnim) { AppState.bootAnim = it; AppState.save() }
                    ToggleRow("Som de inicialização", null, AppState.sound) { AppState.sound = it; AppState.save() }
                    SettingRow("Rever apresentação") { Button(onClick = { AppState.replay = true }) { Text("Assistir") } }
                    SettingRow("Apps fixados no dock", "Fixe outros apps em Store › Instalados") { OutlinedButton(onClick = { AppState.pins = DEFAULT_PINS; AppState.save() }) { Text("Padrão") } }
                }
                "Aparência" -> {
                    H("Aparência"); Text("Cor de destaque", color = Mut); Spacer(Modifier.height(8.dp)); AccentPicker()
                    Spacer(Modifier.height(18.dp)); Text("Ambiente", color = Mut); Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ENVS.forEach { (k, e, n) -> OptionCard(e, n, "", AppState.env == k, Modifier.width(120.dp)) { AppState.env = k; AppState.save() } }
                    }
                }
                "Guardian" -> {
                    H("Guardian")
                    ToggleRow("Guardian ativo", "Avisa ao chegar perto do limite", AppState.guardianOn) { AppState.guardianOn = it; AppState.save() }
                    SettingRow("Distância de aviso", "%.1f m".format(AppState.warnDist)) {
                        Slider(AppState.warnDist, { AppState.warnDist = it; AppState.save() }, valueRange = .2f..1f, modifier = Modifier.width(200.dp))
                    }
                    P("Para redesenhar o limite, abra o app Guardian.")
                }
                "Dispositivo" -> {
                    H("Dispositivo")
                    listOf(
                        "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS, "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
                        "Som" to Settings.ACTION_SOUND_SETTINGS, "Tela" to Settings.ACTION_DISPLAY_SETTINGS,
                        "Apps" to Settings.ACTION_APPLICATION_SETTINGS, "Opções do desenvolvedor" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
                        "Tela inicial padrão" to Settings.ACTION_HOME_SETTINGS, "Configurações do Android" to Settings.ACTION_SETTINGS
                    ).forEach { (n, a) -> SettingRow(n) { OutlinedButton(onClick = { c.openSys(a) }) { Text("Abrir") } } }
                }
                else -> {
                    H("Sobre")
                    SettingRow("Dispositivo", "${Build.MANUFACTURER} ${Build.MODEL}")
                    SettingRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                    SettingRow("EclipseDream XR", "v${BuildConfig.VERSION_NAME}")
                    SettingRow("Shizuku", ShizukuManager.status.name)
                    Button(onClick = { AppState.reset() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444), contentColor = Color.White), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                        Text("Restaurar configurações de fábrica")
                    }
                }
            }
        }
    }
}

/* ---------------- Guardian ---------------- */
fun polyArea(p: List<Offset>) = if (p.size < 3) 0f else
    abs(p.indices.sumOf { i -> val a = p[i]; val b = p[(i + 1) % p.size]; (a.x * b.y - b.x * a.y).toDouble() }).toFloat() / 2f

fun distToPoly(q: Offset, p: List<Offset>): Float = p.indices.minOfOrNull { i ->
    val a = p[i]; val b = p[(i + 1) % p.size]; val v = b - a
    val t = (((q - a).x * v.x + (q - a).y * v.y) / (v.x * v.x + v.y * v.y).coerceAtLeast(1e-6f)).coerceIn(0f, 1f)
    (q - (a + v * t)).getDistance()
} ?: Float.MAX_VALUE

fun pointIn(q: Offset, p: List<Offset>): Boolean {
    var c = false; var j = p.size - 1
    for (i in p.indices) {
        val a = p[i]; val b = p[j]
        if ((a.y > q.y) != (b.y > q.y) && q.x < (b.x - a.x) * (q.y - a.y) / (b.y - a.y) + a.x) c = !c
        j = i
    }
    return c
}

fun vibrate(c: Context) { runCatching { c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE)) } }

@Composable
fun GuardianScreen() {
    val c = LocalContext.current; val scope = rememberCoroutineScope()
    var pts by remember { mutableStateOf(AppState.guardianPts) }
    var test by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf(Offset.Zero) }
    var joy by remember { mutableStateOf(Offset.Zero) }
    var heading by remember { mutableFloatStateOf(0f) }
    val acc = AppState.acc
    val valid = pts.size >= 3
    val inside = valid && pointIn(player, pts)
    val warn = if (!valid || !AppState.guardianOn) 0f else if (!inside) 1f else (1f - distToPoly(player, pts) / AppState.warnDist).coerceIn(0f, 1f)

    LaunchedEffect(test) {
        while (test) {
            val h = heading
            player += Offset(joy.x * cos(h) - joy.y * sin(h), joy.x * sin(h) + joy.y * cos(h)) * 0.04f
            delay(16)
        }
    }
    LaunchedEffect(warn > .6f) { if (test && warn > .6f) vibrate(c) }
    DisposableEffect(test) {
        val sm = c.getSystemService(SensorManager::class.java)
        val s = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9); val o = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(r, e.values); SensorManager.getOrientation(r, o); heading = o[0]
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (test && s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm?.unregisterListener(l) }
    }

    Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Canvas(
                Modifier.aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(Color(0xFF05070C))
                    .border(4.dp, Color(0xFFFF8C00).copy(alpha = warn), RoundedCornerShape(18.dp))
                    .pointerInput(test) {
                        val sc = min(size.width, size.height) / 6f
                        val ctr = Offset(size.width / 2f, size.height / 2f)
                        fun toM(p: Offset) = (p - ctr) / sc
                        detectDragGestures(
                            onDragStart = { if (!test) pts = listOf(toM(it)) },
                            onDrag = { ch, _ -> if (!test) { val p = toM(ch.position); if (pts.isEmpty() || (p - pts.last()).getDistance() > .12f) pts = pts + p } }
                        )
                    }
            ) {
                val sc = size.minDimension / 6f; val ctr = center
                fun px(m: Offset) = ctr + m * sc
                for (i in 0..12) {
                    val v = i * sc / 2
                    drawLine(Color.White.copy(alpha = .07f), Offset(v, 0f), Offset(v, size.height))
                    drawLine(Color.White.copy(alpha = .07f), Offset(0f, v), Offset(size.width, v))
                }
                if (pts.size > 1) {
                    val path = Path().apply { moveTo(px(pts[0]).x, px(pts[0]).y); pts.drop(1).forEach { lineTo(px(it).x, px(it).y) }; close() }
                    drawPath(path, acc.copy(alpha = .18f + warn * .3f))
                    drawPath(path, acc, style = Stroke(width = 4f))
                }
                val pp = px(player)
                drawCircle(acc, 10f, pp)
                drawLine(Color.White, pp, pp + Offset(sin(heading), -cos(heading)) * 28f, strokeWidth = 4f)
            }
        }
        Column(Modifier.width(300.dp).fillMaxHeight().verticalScroll(rememberScrollState())) {
            H("🛡 Guardian")
            P(if (test) "Modo teste: use o joystick e gire o aparelho." else "Arraste no quadro para desenhar (1 quadrado = 50 cm).")
            Text("Área: ${"%.1f".format(polyArea(pts))} m²" + if (valid && polyArea(pts) < 1f) " — mínimo 1 m²" else "", color = Mut)
            Text(
                when { !valid -> "Sem limite"; !inside -> "⚠ FORA DO LIMITE"; warn > 0f -> "Perto da borda"; else -> "✓ Dentro da área" },
                color = if (!inside && valid) Color(0xFFFF5A36) else Color(0xFF4ADE80), fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { pts = emptyList() }) { Text("Limpar") }
                OutlinedButton(onClick = { pts = circle(1f, c = player) }) { Text("Parado") }
            }
            Button(onClick = {
                if (!valid || polyArea(pts) < 1f) c.toast("Desenhe uma área maior")
                else { AppState.guardianPts = pts; AppState.guardianOn = true; AppState.save(); c.toast("Guardian salvo ✓") }
            }, modifier = Modifier.fillMaxWidth()) { Text("Salvar limite") }
            ToggleRow("Modo teste", "Joystick + sensor de rotação", test) { test = it; player = Offset.Zero }
            if (test) Joystick { joy = it }
            if (isQuest && ShizukuManager.ready) {
                Text("Guardian do sistema (Shizuku, não oficial)", color = Mut, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { scope.launch { c.toast(ShizukuManager.exec("setprop debug.oculus.guardian_pause 1").trim()) } }) { Text("Pausar") }
                    OutlinedButton(onClick = { scope.launch { c.toast(ShizukuManager.exec("setprop debug.oculus.guardian_pause 0").trim()) } }) { Text("Retomar") }
                }
            }
        }
    }
}

@Composable
fun Joystick(onMove: (Offset) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    val r = 60f
    Box(
        Modifier.padding(top = 10.dp).size(140.dp).clip(CircleShape).background(Color.White.copy(alpha = .08f))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { knob = Offset.Zero; onMove(Offset.Zero) },
                    onDrag = { ch, d ->
                        val n = knob + d
                        knob = if (n.getDistance() > r * density) n / n.getDistance() * (r * density) else n
                        onMove(knob / (r * density))
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.offset { androidx.compose.ui.unit.IntOffset(knob.x.toInt(), knob.y.toInt()) }.size(52.dp).clip(CircleShape).background(AppState.acc))
    }
}

/* ---------------- Shizuku ---------------- */
@Composable
fun ShizukuScreen(onOpen: (Scr) -> Unit) {
    val c = LocalContext.current; val scope = rememberCoroutineScope()
    val st = ShizukuManager.status
    var cmd by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    val run: (String) -> Unit = { k -> scope.launch { out += "$ $k\n" + ShizukuManager.exec(k).trimEnd() + "\n" } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon("⚡", Color(0xFF3F51B5), size = 64.dp); Spacer(Modifier.width(14.dp))
            Column { H("Shizuku"); Text("API privilegiada via ADB ou root", color = Mut) }
        }
        val (msg, ok) = when (st) {
            ShizukuManager.St.NOT_INSTALLED -> "Shizuku não está instalado" to false
            ShizukuManager.St.NOT_RUNNING -> "Instalado, mas não está rodando" to false
            ShizukuManager.St.NO_PERMISSION -> "Rodando — falta autorizar o EclipseDream" to false
            ShizukuManager.St.CONNECTING -> "Conectando ao serviço…" to false
            ShizukuManager.St.READY -> "✓ Ativo · ${if (ShizukuManager.uid == 0) "root" else "ADB (shell)"} · API v${ShizukuManager.version}" to true
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 14.dp).clip(RoundedCornerShape(14.dp))
                .background(if (ok) Color(0x2222C55E) else Color(0x22FFA000)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(msg, modifier = Modifier.weight(1f))
            when (st) {
                ShizukuManager.St.NOT_INSTALLED -> Button(onClick = { onOpen(Scr.Store) }) { Text("Instalar pela Store") }
                ShizukuManager.St.NOT_RUNNING -> Button(onClick = { c.launch(SHIZUKU_PKG) }) { Text("Abrir Shizuku") }
                ShizukuManager.St.NO_PERMISSION -> Button(onClick = { ShizukuManager.requestPermission() }) { Text("Autorizar") }
                ShizukuManager.St.CONNECTING -> CircularProgressIndicator(Modifier.size(28.dp))
                ShizukuManager.St.READY -> OutlinedButton(onClick = { ShizukuManager.refresh() }) { Text("Atualizar") }
            }
        }
        Text("Como iniciar no Quest", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        P("1. Ative o modo desenvolvedor no app Meta Horizon do celular.\n2. Abra o Shizuku e toque em Parear.\n3. Vá em Configurações › Sistema › Opções do desenvolvedor › Depuração sem fio › Parear com código.\n4. Digite o código de 6 dígitos no Shizuku e toque em Iniciar.\nPelo PC: adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh")
        OutlinedButton(onClick = { c.openSys(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }) { Text("Abrir Opções do desenvolvedor") }
        if (ok) {
            Text("Ações rápidas", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("whoami", "getprop ro.product.model", "pm list packages -3", "dumpsys battery | head -n 12", "df -h /data").forEach { k -> Chip(k, false) { run(k) } }
            }
            Text(
                out.ifEmpty { "Terminal com privilégio de ${if (ShizukuManager.uid == 0) "root" else "shell"}.\n" },
                fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFF7CFC9A),
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp).heightIn(min = 160.dp, max = 320.dp)
                    .clip(RoundedCornerShape(12.dp)).background(Color(0xFF05070A)).verticalScroll(rememberScrollState()).padding(12.dp)
            )
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    cmd, { cmd = it }, singleLine = true, placeholder = { Text("comando…") }, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (cmd.isNotBlank()) { run(cmd); cmd = "" } })
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { if (cmd.isNotBlank()) { run(cmd); cmd = "" } }) { Text("⏎") }
                RoundBtn("🧹") { out = "" }
            }
        }
    }
}
