package com.eclipsedream.xr

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import kotlin.system.exitProcess

/** Roda num processo separado com identidade shell (2000) ou root (0). */
class ShellService : IShellService.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun exec(cmd: String?): String = try {
        val p = ProcessBuilder("sh", "-c", cmd ?: "").redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        out.ifBlank { "(sem saída · código $code)" }
    } catch (e: Exception) { "Erro: ${e.message}" }

    override fun installApk(pfd: ParcelFileDescriptor?, size: Long): String = try {
        val p = ProcessBuilder("pm", "install", "-r", "-S", size.toString()).redirectErrorStream(true).start()
        ParcelFileDescriptor.AutoCloseInputStream(pfd).use { i -> p.outputStream.use { o -> i.copyTo(o) } }
        val out = p.inputStream.bufferedReader().readText(); p.waitFor(); out.trim()
    } catch (e: Exception) { "Erro: ${e.message}" }
}

object ShizukuManager {
    enum class St { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, CONNECTING, READY }

    var status by mutableStateOf(St.NOT_RUNNING); private set
    var uid by mutableIntStateOf(-1); private set
    var version by mutableIntStateOf(-1); private set
    val ready get() = status == St.READY

    private var service: IShellService? = null
    private var inited = false
    private lateinit var app: Context

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(BuildConfig.APPLICATION_ID, ShellService::class.java.name))
            .daemon(false).processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG).version(BuildConfig.VERSION_CODE)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                service = IShellService.Stub.asInterface(binder); status = St.READY
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null; refresh() }
    }

    fun init(c: Context) {
        if (inited) return
        inited = true; app = c.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener { service = null; refresh() }
        Shizuku.addRequestPermissionResultListener { _, r ->
            if (r == PackageManager.PERMISSION_GRANTED) refresh() else status = St.NO_PERMISSION
        }
        refresh()
    }

    fun installed() = runCatching { app.packageManager.getPackageInfo(SHIZUKU_PKG, 0) }.isSuccess

    fun refresh() {
        if (!inited) return
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                service = null
                status = if (installed()) St.NOT_RUNNING else St.NOT_INSTALLED; return
            }
            uid = Shizuku.getUid(); version = Shizuku.getVersion()
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { status = St.NO_PERMISSION; return }
            if (service?.asBinder()?.pingBinder() == true) { status = St.READY; return }
            status = St.CONNECTING
            Shizuku.bindUserService(args, conn)
        } catch (e: Throwable) { status = St.NOT_RUNNING }
    }

    fun requestPermission() { runCatching { Shizuku.requestPermission(4242) } }

    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        service?.exec(cmd) ?: "Shizuku não conectado"
    }

    suspend fun install(f: File): String = withContext(Dispatchers.IO) {
        val s = service ?: return@withContext "Shizuku não conectado"
        s.installApk(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), f.length())
    }
}
