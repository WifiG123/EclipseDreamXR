package com.eclipsedream.xr

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin

val DEFAULT_PINS = listOf("google", "youtube", "browser", "store", "settings")

fun circle(r: Float, n: Int = 24, c: Offset = Offset.Zero) = List(n) {
    val a = it * 2 * Math.PI / n
    Offset(c.x + (cos(a) * r).toFloat(), c.y + (sin(a) * r).toFloat())
}

object AppState {
    private lateinit var sp: SharedPreferences
    var setupDone by mutableStateOf(false)
    var name by mutableStateOf("Jogador")
    var accent by mutableIntStateOf(0xFFFF8C00.toInt())
    var env by mutableStateOf("eclipse")
    var bootAnim by mutableStateOf(true)
    var sound by mutableStateOf(true)
    var guardianOn by mutableStateOf(true)
    var guardianPts by mutableStateOf(circle(1.5f))
    var warnDist by mutableFloatStateOf(0.4f)
    var pins by mutableStateOf(DEFAULT_PINS)
    var pkgTick by mutableIntStateOf(0)
    var replay by mutableStateOf(false)
    val acc: Color get() = Color(accent)

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("edxr", Context.MODE_PRIVATE); load()
    }

    private fun load() {
        setupDone = sp.getBoolean("setup", false)
        name = sp.getString("name", "Jogador") ?: "Jogador"
        accent = sp.getInt("accent", 0xFFFF8C00.toInt())
        env = sp.getString("env", "eclipse") ?: "eclipse"
        bootAnim = sp.getBoolean("boot", true)
        sound = sp.getBoolean("sound", true)
        guardianOn = sp.getBoolean("gOn", true)
        warnDist = sp.getFloat("gWarn", 0.4f)
        guardianPts = sp.getString("gPts", null)?.let { s ->
            runCatching { s.split(";").map { p -> p.split(",").let { Offset(it[0].toFloat(), it[1].toFloat()) } } }.getOrNull()
        } ?: circle(1.5f)
        pins = sp.getString("pins", null)?.split(",")?.filter { it.isNotBlank() } ?: DEFAULT_PINS
    }

    fun save() {
        sp.edit()
            .putBoolean("setup", setupDone).putString("name", name).putInt("accent", accent)
            .putString("env", env).putBoolean("boot", bootAnim).putBoolean("sound", sound)
            .putBoolean("gOn", guardianOn).putFloat("gWarn", warnDist)
            .putString("gPts", guardianPts.joinToString(";") { "${it.x},${it.y}" })
            .putString("pins", pins.joinToString(","))
            .apply()
    }

    fun reset() { sp.edit().clear().commit(); load() }
}
