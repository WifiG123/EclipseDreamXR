package com.eclipsedream.xr

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.init(this)
        ShizukuManager.init(this)
        enableEdgeToEdge()
        setContent { EclipseTheme { Root() } }
    }
    override fun onResume() {
        super.onResume()
        AppState.pkgTick++
        ShizukuManager.refresh()
    }
}

const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
val isQuest: Boolean get() = Build.MANUFACTURER.equals("Oculus", true) || Build.MANUFACTURER.equals("Meta", true)
val Mut = Color(0xFF9AA0AA)
val ACCENTS = listOf(0xFFFF8C00, 0xFFEF4444, 0xFF22C55E, 0xFF3B82F6, 0xFFA855F7, 0xFFEC4899, 0xFF14B8A6).map { it.toInt() }
val ENVS = listOf(
    Triple("eclipse", "☾", "Eclipse"), Triple("espaco", "🌌", "Espaço"), Triple("aurora", "🌠", "Aurora"),
    Triple("lago", "🌅", "Lago"), Triple("estudio", "⬜", "Estúdio")
)

sealed interface Scr {
    data object Home : Scr
    data class Web(val url: String, val title: String) : Scr
    data object Store : Scr
    data object Settings : Scr
    data object Guardian : Scr
    data object Shizuku : Scr
}

data class Builtin(val id: String, val name: String, val glyph: String, val bg: Color, val cat: String, val scr: Scr, val fg: Color = Color.White)

val BUILTINS = listOf(
    Builtin("google", "Google", "G", Color.White, "Google", Scr.Web("https://www.google.com", "Google"), Color(0xFF4285F4)),
    Builtin("youtube", "YouTube", "▶", Color(0xFFFF0000), "Google", Scr.Web("https://m.youtube.com", "YouTube")),
    Builtin("gmail", "Gmail", "M", Color(0xFFEA4335), "Google", Scr.Web("https://mail.google.com", "Gmail")),
    Builtin("maps", "Maps", "📍", Color(0xFF34A853), "Google", Scr.Web("https://www.google.com/maps", "Google Maps")),
    Builtin("drive", "Drive", "△", Color(0xFF1E8E3E), "Google", Scr.Web("https://drive.google.com", "Google Drive")),
    Builtin("translate", "Tradutor", "文", Color(0xFF4285F4), "Google", Scr.Web("https://translate.google.com", "Google Tradutor")),
    Builtin("photos", "Fotos", "✿", Color(0xFFFBBC05), "Google", Scr.Web("https://photos.google.com", "Google Fotos")),
    Builtin("browser", "Navegador", "🌐", Color(0xFF1A73E8), "Sistema", Scr.Web("https://duckduckgo.com", "Navegador")),
    Builtin("store", "Store", "🛍", Color(0xFFFF3D6E), "Sistema", Scr.Store),
    Builtin("settings", "Configurações", "⚙", Color(0xFF5F6368), "Sistema", Scr.Settings),
    Builtin("guardian", "Guardian", "🛡", Color(0xFFFFB000), "Sistema", Scr.Guardian),
    Builtin("shizuku", "Shizuku", "⚡", Color(0xFF3F51B5), "Sistema", Scr.Shizuku),
)
fun builtin(id: String) = BUILTINS.firstOrNull { it.id == id }

fun titleOf(s: Scr) = when (s) {
    is Scr.Web -> s.title; Scr.Store -> "Store"; Scr.Settings -> "Configurações"
    Scr.Guardian -> "Guardian"; Scr.Shizuku -> "Shizuku"; Scr.Home -> "Início"
}

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
fun Context.openSys(action: String) {
    try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { toast("Indisponível neste dispositivo") }
}

@Composable
fun EclipseTheme(content: @Composable () -> Unit) {
    val a = AppState.acc
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = a, onPrimary = Color.Black, secondary = a, background = Color.Black,
            surface = Color(0xFF16181E), onSurface = Color(0xFFF2F3F5), surfaceVariant = Color(0xFF22252D)
        ), content = content
    )
}

@Composable
fun Root() {
    var booted by rememberSaveable { mutableStateOf(!AppState.bootAnim) }
    when {
        !booted || AppState.replay -> BootScreen { booted = true; AppState.replay = false }
        !AppState.setupDone -> SetupScreen()
        else -> Shell()
    }
}

@Composable
fun Shell() {
    var scr by remember { mutableStateOf<Scr>(Scr.Home) }
    var qs by remember { mutableStateOf(false) }
    BackHandler(scr != Scr.Home || qs) { if (qs) qs = false else scr = Scr.Home }
    Box(Modifier.fillMaxSize()) {
        EnvBackground(AppState.env)
        Box(Modifier.fillMaxSize().systemBarsPadding().padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp)) {
            Crossfade(targetState = scr, label = "scr") { s ->
                if (s == Scr.Home) HomeScreen { scr = it }
                else Panel(titleOf(s), onClose = { scr = Scr.Home }) {
                    when (s) {
                        is Scr.Web -> WebScreen(s.url)
                        Scr.Store -> StoreScreen()
                        Scr.Settings -> SettingsScreen()
                        Scr.Guardian -> GuardianScreen()
                        Scr.Shizuku -> ShizukuScreen { scr = it }
                        else -> {}
                    }
                }
            }
        }
        Dock(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp),
            onOpen = { qs = false; scr = it }, onQs = { qs = !qs }
        )
        if (qs) QuickSettings(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 92.dp)
        ) { qs = false; scr = it }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(28.dp), content: @Composable BoxScope.() -> Unit) =
    Box(modifier.clip(shape).background(Color(0xEB141820)).border(1.dp, Color.White.copy(alpha = .12f), shape), content = content)

@Composable
fun Panel(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Glass(Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(AppState.acc))
                    Spacer(Modifier.width(10.dp))
                    Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    RoundBtn("✕", onClick = onClose)
                }
                HorizontalDivider(color = Color.White.copy(alpha = .07f))
                Box(Modifier.fillMaxSize()) { content() }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.width(120.dp).height(6.dp).clip(CircleShape).background(Color.White.copy(alpha = .45f)))
    }
}

@Composable
fun RoundBtn(text: String, size: Dp = 40.dp, on: Boolean = false, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val hov by src.collectIsHoveredAsState()
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(if (on) AppState.acc else if (hov) Color.White.copy(alpha = .14f) else Color.Transparent)
            .hoverable(src).clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = (size.value * 0.42f).sp, color = if (on) Color.Black else Color.White) }
}

@Composable
fun AppIcon(glyph: String = "", bg: Color = Color.DarkGray, fg: Color = Color.White, size: Dp = 60.dp, image: ImageBitmap? = null) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(if (image != null) Color.Transparent else bg),
        contentAlignment = Alignment.Center
    ) {
        if (image != null) Image(image, null, Modifier.fillMaxSize())
        else Text(glyph, color = fg, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun AppTile(name: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val hov by src.collectIsHoveredAsState()
    val sc by animateFloatAsState(if (hov) 1.08f else 1f, label = "tile")
    Column(
        Modifier.clip(RoundedCornerShape(18.dp))
            .background(if (hov) Color.White.copy(alpha = .08f) else Color.Transparent)
            .hoverable(src).clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
            .padding(10.dp).scale(sc),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Spacer(Modifier.height(8.dp))
        Text(name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun AccentPicker() = Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    ACCENTS.forEach { c ->
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(c))
                .border(3.dp, if (AppState.accent == c) Color.White else Color.Transparent, CircleShape)
                .clickable { AppState.accent = c; AppState.save() }
        )
    }
}

@Composable
fun OptionCard(emoji: String, title: String, desc: String, sel: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.clip(shape)
            .background(if (sel) AppState.acc.copy(alpha = .14f) else Color.White.copy(alpha = .05f))
            .border(2.dp, if (sel) AppState.acc else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(14.dp)
    ) {
        Text(emoji, fontSize = 26.sp)
        Text(title, fontWeight = FontWeight.Bold)
        if (desc.isNotEmpty()) Text(desc, fontSize = 12.sp, color = Mut)
    }
}

@Composable
fun SettingRow(title: String, sub: String? = null, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = .045f)).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (sub != null) Text(sub, color = Mut, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun ToggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) =
    SettingRow(title, sub) { Switch(checked, onChange) }

@Composable fun H(t: String) = Text(t, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
@Composable fun P(t: String) = Text(t, color = Color(0xFFB9BEC7), fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))
