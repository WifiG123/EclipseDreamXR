package com.eclipsedream.xr

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.foundation.Canvas
import kotlin.concurrent.thread
import kotlin.math.*
import kotlin.random.Random

object Chime {
    fun play() = thread {
        try {
            Thread.sleep(1400)
            val sr = 44100; val dur = 3.4; val n = (sr * dur).toInt()
            val buf = ShortArray(n)
            val freqs = listOf(220.0, 330.0, 440.0, 660.0, 880.0)
            for (i in 0 until n) {
                val t = i / sr.toDouble(); var s = 0.0
                freqs.forEachIndexed { k, f ->
                    val st = k * 0.18
                    if (t >= st) { val tt = t - st; s += sin(2 * PI * f * tt) * min(1.0, tt / 0.05) * exp(-tt * 1.5) * 0.15 }
                }
                buf[i] = (s.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
            }
            val at = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
            at.write(buf, 0, n); at.play()
            Thread.sleep((dur * 1000).toLong() + 200); at.release()
        } catch (_: Exception) {}
    }
}

@Composable
fun BootScreen(onDone: () -> Unit) {
    val total = 6.8f
    val t = remember { Animatable(0f) }
    val acc = AppState.acc
    LaunchedEffect(Unit) {
        if (AppState.sound) Chime.play()
        t.animateTo(total, tween((total * 1000).toInt(), easing = LinearEasing))
        onDone()
    }
    val stars = remember { List(450) { floatArrayOf(Random.nextFloat() * 2 - 1, Random.nextFloat() * 2 - 1, Random.nextFloat()) } }
    val time = t.value
    val fade = if (time > total - 0.6f) 1f - (time - (total - 0.6f)) / 0.6f else 1f

    Box(Modifier.fillMaxSize().background(Color.Black).graphicsLayer { alpha = fade.coerceIn(0f, 1f) }) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2; val cy = size.height * 0.4f
            val decay = exp(-time * 1.1f)
            val travel = 3f * (1f - decay) + 0.06f * time
            val k = size.minDimension * 0.3f
            // túnel de estrelas (warp)
            stars.forEach { s ->
                val z = ((s[2] - travel) % 1f + 1f) % 1f + 0.02f
                val tail = z + 0.02f + 0.25f * decay
                val p1 = Offset(cx + s[0] / z * k, cy + s[1] / z * k)
                val p0 = Offset(cx + s[0] / tail * k, cy + s[1] / tail * k)
                val a = (1f - z).coerceIn(0f, 1f)
                drawLine(lerp(acc, Color.White, 0.5f).copy(alpha = a), p0, p1, strokeWidth = 1f + 3f * a)
            }
            // eclipse se formando
            val e = ((time - 1.4f) / 1.2f).coerceIn(0f, 1f)
            if (e > 0f) {
                val r = size.minDimension * 0.18f * (1f - (1f - e).pow(3))
                val c = Offset(cx, cy)
                drawCircle(Brush.radialGradient(listOf(acc.copy(alpha = .6f), Color.Transparent), c, r * 3.2f + 1f), r * 3.2f + 1f, c)
                rotate(time * 50f, c) {
                    drawCircle(Brush.sweepGradient(listOf(Color.Transparent, acc, Color.Transparent, Color(0xFFFFD000), Color.Transparent, Color(0xFFFF5A36), Color.Transparent), c), r * 1.3f + 1f, c, alpha = .75f)
                }
                drawCircle(Color(0xFFFFE0B0), r * 1.05f, c)
                drawCircle(Color.Black, r, c)
                val d = ((time - 1.6f) / 1.3f).coerceIn(0f, 1f)
                if (d > 0f && d < 1f) {
                    val al = sin(d * PI).toFloat(); val dc = Offset(cx + r * .7f, cy - r * .7f)
                    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = al), Color.Transparent), dc, r * .7f + 1f), r * .7f + 1f, dc)
                }
            }
            val f = (1f - abs(time - 1.45f) / 0.5f).coerceIn(0f, 1f)
            if (f > 0f) drawRect(Color.White.copy(alpha = f * .9f))
        }
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.fillMaxHeight(0.62f))
            Row {
                "EclipseDream XR".forEachIndexed { i, ch ->
                    val p = ((time - 2.6f - i * 0.05f) / 0.6f).coerceIn(0f, 1f)
                    Text(
                        ch.toString(),
                        style = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, shadow = Shadow(acc, blurRadius = 30f)),
                        modifier = Modifier.graphicsLayer { alpha = p; translationY = (1 - p) * 40f; scaleX = .8f + .2f * p; scaleY = .8f + .2f * p }
                    )
                }
            }
            val sp = ((time - 3.6f) / 0.8f).coerceIn(0f, 1f)
            Text("HORIZON · MIXED REALITY", color = acc, fontSize = 12.sp, letterSpacing = (5 + 4 * (1 - sp)).sp, modifier = Modifier.graphicsLayer { alpha = sp })
            Spacer(Modifier.height(36.dp))
            Box(Modifier.width(240.dp).height(3.dp).graphicsLayer { alpha = sp }.clip(CircleShape).background(Color.White.copy(alpha = .1f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(((time - 3.6f) / 2.6f).coerceIn(0f, 1f)).background(Brush.horizontalGradient(listOf(acc, Color.White))))
            }
        }
        TextButton(onClick = onDone, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Text("Pular ›", color = Mut) }
    }
}

@Composable
fun SetupScreen() {
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf(AppState.name) }
    var gType by remember { mutableStateOf("room") }
    Box(Modifier.fillMaxSize()) {
        EnvBackground("eclipse")
        Glass(Modifier.align(Alignment.Center).widthIn(max = 560.dp).fillMaxWidth(0.92f)) {
            Column(Modifier.padding(28.dp).verticalScroll(rememberScrollState())) {
                Row(Modifier.padding(bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(5) { Box(Modifier.weight(1f).height(4.dp).clip(CircleShape).background(if (it <= step) AppState.acc else Color.White.copy(alpha = .12f))) }
                }
                when (step) {
                    0 -> { Text("☾", fontSize = 56.sp, color = AppState.acc); H("Bem-vindo ao EclipseDream XR"); P("Vamos configurar seu headset. Leva menos de um minuto.") }
                    1 -> {
                        H("Seu perfil")
                        OutlinedTextField(name, { name = it.take(20) }, label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(14.dp)); Text("Cor de destaque", color = Mut); Spacer(Modifier.height(8.dp)); AccentPicker()
                    }
                    2 -> {
                        H("Ambiente virtual")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ENVS.forEach { (k, e, n) -> OptionCard(e, n, "", AppState.env == k, Modifier.width(120.dp)) { AppState.env = k; AppState.save() } }
                        }
                    }
                    3 -> {
                        H("🛡 Guardian"); P("Escolha seu limite de segurança.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(Triple("room", "🏠", "Sala"), Triple("station", "🪑", "Parado"), Triple("off", "⛔", "Desligado")).forEach { (k, e, n) ->
                                OptionCard(e, n, "", gType == k, Modifier.weight(1f)) { gType = k }
                            }
                        }
                    }
                    else -> { Text("✓", fontSize = 56.sp, color = AppState.acc); H("Tudo pronto, ${name.ifBlank { "Jogador" }}!"); P("Use o dock embaixo para abrir apps. Instale o Shizuku pela Store para liberar instalação silenciosa e o terminal.") }
                }
                Button(onClick = {
                    if (step < 4) step++ else {
                        AppState.name = name.ifBlank { "Jogador" }
                        AppState.guardianOn = gType != "off"
                        if (gType == "station") AppState.guardianPts = circle(1f)
                        AppState.setupDone = true; AppState.save()
                    }
                }, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) { Text(if (step < 4) "Continuar" else "Entrar no Horizon") }
            }
        }
    }
}
