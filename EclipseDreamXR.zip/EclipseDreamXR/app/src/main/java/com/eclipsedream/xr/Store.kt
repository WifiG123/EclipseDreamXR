package com.eclipsedream.xr

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class StoreApp(val repo: String, val pkg: String, val name: String, val desc: String, val glyph: String, val bg: Color, val cat: String)

val CATALOG = listOf(
    StoreApp("RikkaApps/Shizuku", SHIZUKU_PKG, "Shizuku", "Permissões ADB/root para apps", "⚡", Color(0xFF3F51B5), "Sistema"),
    StoreApp("ImranR98/Obtainium", "dev.imranr.obtainium", "Obtainium", "Atualiza apps direto da fonte", "⬇", Color(0xFF6750A4), "Sistema"),
    StoreApp("MuntashirAkon/AppManager", "io.github.muntashirakon.AppManager", "App Manager", "Gerenciador avançado de apps", "🧩", Color(0xFF00796B), "Ferramentas"),
    StoreApp("termux/termux-app", "com.termux", "Termux", "Terminal Linux completo", ">_", Color(0xFF111111), "Ferramentas"),
    StoreApp("TeamNewPipe/NewPipe", "org.schabi.newpipe", "NewPipe", "YouTube leve, sem anúncios", "▶", Color(0xFFCD201F), "Entretenimento"),
    StoreApp("libre-tube/LibreTube", "com.github.libretube", "LibreTube", "YouTube via Piped", "▷", Color(0xFFE53935), "Entretenimento"),
)

fun isInstalled(c: Context, pkg: String) = runCatching { c.packageManager.getPackageInfo(pkg, 0) }.isSuccess

suspend fun fetchLatest(repo: String): Pair<String, String> = withContext(Dispatchers.IO) {
    val con = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
    con.setRequestProperty("Accept", "application/vnd.github+json")
    val j = JSONObject(con.inputStream.bufferedReader().readText())
    val arr = j.getJSONArray("assets")
    val apks = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.getString("name").endsWith(".apk") }
    val pick = apks.firstOrNull { it.getString("name").contains("arm64") }
        ?: apks.firstOrNull { a -> listOf("x86", "armeabi").none { a.getString("name").contains(it) } }
        ?: apks.firstOrNull() ?: error("Release sem APK")
    j.getString("tag_name") to pick.getString("browser_download_url")
}

suspend fun download(url: String, f: File, onP: (Float) -> Unit) = withContext(Dispatchers.IO) {
    val con = URL(url).openConnection() as HttpURLConnection
    con.instanceFollowRedirects = true
    val len = con.contentLengthLong
    con.inputStream.use { i ->
        f.outputStream().use { o ->
            val buf = ByteArray(64 * 1024); var t = 0L
            while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); t += n; if (len > 0) onP(t.toFloat() / len) }
        }
    }
}

suspend fun installApk(c: Context, f: File): String {
    if (ShizukuManager.ready) return ShizukuManager.install(f)
    if (!c.packageManager.canRequestPackageInstalls()) {
        c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Permita 'instalar apps desconhecidos' e tente de novo"
    }
    val uri = FileProvider.getUriForFile(c, "${c.packageName}.files", f)
    c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    return "Abrindo instalador…"
}

fun uninstall(c: Context, scope: CoroutineScope, pkg: String) {
    if (ShizukuManager.ready) scope.launch { c.toast(ShizukuManager.exec("pm uninstall $pkg").trim()); AppState.pkgTick++ }
    else c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun SideNav(items: List<String>, sel: String, onSel: (String) -> Unit) = Column(Modifier.width(190.dp).fillMaxHeight().padding(12.dp)) {
    items.forEach { t ->
        Text(
            t, fontSize = 14.sp, color = if (t == sel) AppState.acc else Color.White,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (t == sel) Color.White.copy(alpha = .1f) else Color.Transparent).clickable { onSel(t) }.padding(12.dp)
        )
    }
}

val rowMod = Modifier.fillMaxWidth().padding(bottom = 8.dp)

@Composable
fun StoreScreen() {
    val c = LocalContext.current; val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("Descobrir") }
    val prog = remember { mutableStateMapOf<String, Float>() }
    val tick = AppState.pkgTick
    val apps = rememberApps()
    fun get(a: StoreApp) = scope.launch {
        prog[a.pkg] = 0f
        try {
            val (tag, url) = fetchLatest(a.repo)
            val f = File(c.cacheDir, "apks").apply { mkdirs() }.resolve("${a.pkg}.apk")
            download(url, f) { prog[a.pkg] = it }
            c.toast("${a.name} $tag: " + installApk(c, f))
        } catch (e: Exception) { c.toast("Erro: ${e.message}") } finally { prog.remove(a.pkg); AppState.pkgTick++ }
    }
    Row(Modifier.fillMaxSize()) {
        SideNav(listOf("Descobrir", "Sistema", "Ferramentas", "Entretenimento", "Instalados"), tab) { tab = it }
        LazyColumn(Modifier.weight(1f).fillMaxHeight().padding(18.dp)) {
            if (tab == "Descobrir") item {
                Column(rowMod.clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(AppState.acc, Color(0xFF7A1FA2)))).padding(24.dp)) {
                    Text("EM DESTAQUE", fontSize = 11.sp); Text("Shizuku", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Instala apps em silêncio e libera o terminal com permissão de ADB.")
                    if (ShizukuManager.status != ShizukuManager.St.NOT_INSTALLED) Text("✓ Já instalado", fontWeight = FontWeight.Bold)
                }
            }
            if (tab == "Instalados") items(apps, key = { it.pkg }) { a ->
                Row(rowMod.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .045f)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(image = a.icon, size = 48.dp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(a.label, fontWeight = FontWeight.Bold); Text(a.pkg + if (a.vr) " · VR" else "", color = Mut, fontSize = 12.sp) }
                    val pinned = a.pkg in AppState.pins
                    RoundBtn(if (pinned) "📌" else "📍", on = pinned) { AppState.pins = if (pinned) AppState.pins - a.pkg else AppState.pins + a.pkg; AppState.save() }
                    RoundBtn("🗑") { uninstall(c, scope, a.pkg) }
                }
            } else items(CATALOG.filter { tab == "Descobrir" || it.cat == tab }, key = { it.pkg }) { a ->
                val inst = remember(tick) { isInstalled(c, a.pkg) }
                Row(rowMod.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .045f)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(a.glyph, a.bg, size = 54.dp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(a.name, fontWeight = FontWeight.Bold); Text("${a.desc} · github.com/${a.repo}", color = Mut, fontSize = 12.sp) }
                    val p = prog[a.pkg]
                    when {
                        p != null -> CircularProgressIndicator(progress = { p }, modifier = Modifier.size(36.dp))
                        inst -> {
                            Button(onClick = { c.launch(a.pkg) }) { Text("Abrir") }
                            Spacer(Modifier.width(6.dp)); OutlinedButton(onClick = { get(a) }) { Text("Atualizar") }
                            RoundBtn("🗑") { uninstall(c, scope, a.pkg) }
                        }
                        else -> Button(onClick = { get(a) }) { Text("Instalar") }
                    }
                }
            }
        }
    }
}
