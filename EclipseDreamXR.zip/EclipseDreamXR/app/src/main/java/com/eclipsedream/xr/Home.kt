package com.eclipsedream.xr

import android.app.Activity
import android.content.*
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class LApp(val pkg: String, val label: String, val icon: ImageBitmap, val vr: Boolean)

fun loadApps(c: Context): List<LApp> {
    val pm = c.packageManager
    val out = LinkedHashMap<String, LApp>()
    listOf(Intent.CATEGORY_LAUNCHER to false, "com.oculus.intent.category.VR" to true).forEach { (cat, vr) ->
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0).forEach { ri ->
            val p = ri.activityInfo.packageName
            if (p != c.packageName && out[p]?.vr != true) runCatching {
                out[p] = LApp(p, ri.loadLabel(pm).toString(), ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap(), vr)
            }
        }
    }
    return out.values.sortedBy { it.label.lowercase() }
}

fun Context.launch(pkg: String) {
    val i = packageManager.getLaunchIntentForPackage(pkg)
        ?: Intent(Intent.ACTION_MAIN).addCategory("com.oculus.intent.category.VR").setPackage(pkg)
    try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Não foi possível abrir") }
}

@Composable
fun rememberApps(): List<LApp> {
    val c = LocalContext.current
    val apps by produceState(emptyList<LApp>(), AppState.pkgTick) { value = withContext(Dispatchers.IO) { loadApps(c) } }
    return apps
}

fun now(f: String): String = SimpleDateFormat(f, Locale("pt", "BR")).format(Date())

@Composable
fun rememberClock(fmt: String = "HH:mm"): String {
    val s by produceState(now(fmt)) { while (true) { value = now(fmt); delay(1000) } }
    return s
}

@Composable
fun rememberBattery(): Pair<Int, Boolean> {
    val c = LocalContext.current
    val b by produceState(-1 to false) {
        while (true) {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = (i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
            val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            value = (l * 100 / sc) to (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
            delay(30_000)
        }
    }
    return b
}

@Composable
fun Chip(t: String, on: Boolean, onClick: () -> Unit) = Text(
    t, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.Black else Color.White,
    modifier = Modifier.clip(CircleShape).background(if (on) Color.White else Color.White.copy(alpha = .08f)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
)

@Composable
fun HomeScreen(onOpen: (Scr) -> Unit) {
    val c = LocalContext.current
    val apps = rememberApps()
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Todos") }
    val time = rememberClock(); val date = rememberClock("EEEE, d 'de' MMMM")
    val search = { if (q.isNotBlank()) onOpen(Scr.Web("https://www.google.com/search?q=" + Uri.encode(q), "Google")) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(time, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
                Text("${date.replaceFirstChar { it.uppercase() }} · Olá, ${AppState.name}", color = Color(0xFFCFD3DA))
            }
            val ready = ShizukuManager.ready
            Text(
                if (ready) "⚡ Shizuku ativo" else "⚡ Shizuku off", fontSize = 13.sp, color = if (ready) Color(0xFF4ADE80) else Mut,
                modifier = Modifier.clip(CircleShape).background(Color(0xCC141820)).clickable { onOpen(Scr.Shizuku) }.padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
        Glass(Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        q, { q = it }, placeholder = { Text("Pesquisar apps ou no Google…") }, singleLine = true,
                        shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { search() })
                    )
                    Spacer(Modifier.width(8.dp)); Button(onClick = search) { Text("Buscar") }
                }
                Row(Modifier.padding(vertical = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Todos", "Google", "Sistema", "Apps", "VR").forEach { t -> Chip(t, tab == t) { tab = t } }
                }
                val ql = q.trim().lowercase()
                val bs = BUILTINS.filter { (tab == "Todos" || it.cat == tab) && it.name.lowercase().contains(ql) }
                val ins = apps.filter { (tab == "Todos" || (tab == "Apps" && !it.vr) || (tab == "VR" && it.vr)) && it.label.lowercase().contains(ql) }
                LazyVerticalGrid(GridCells.Adaptive(104.dp), Modifier.fillMaxSize()) {
                    items(bs, key = { "b_" + it.id }) { b -> AppTile(b.name, { onOpen(b.scr) }) { AppIcon(b.glyph, b.bg, b.fg) } }
                    items(ins, key = { "p_" + it.pkg }) { a -> AppTile(a.label, { c.launch(a.pkg) }) { AppIcon(image = a.icon) } }
                }
            }
        }
    }
}

@Composable
fun DockBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val hov by src.collectIsHoveredAsState()
    val sc by animateFloatAsState(if (hov) 1.12f else 1f, label = "dock")
    Box(Modifier.scale(sc).clip(RoundedCornerShape(14.dp)).hoverable(src).clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)) { content() }
}

@Composable
fun Dock(modifier: Modifier, onOpen: (Scr) -> Unit, onQs: () -> Unit) {
    val c = LocalContext.current
    val apps = rememberApps()
    val time = rememberClock(); val (bat, chg) = rememberBattery()
    Glass(modifier, CircleShape) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DockBtn({ onOpen(Scr.Home) }) { AppIcon("▦", Color(0xFF333333), size = 46.dp) }
            Box(Modifier.width(1.dp).height(30.dp).background(Color.White.copy(alpha = .15f)))
            AppState.pins.forEach { id ->
                val b = builtin(id)
                if (b != null) DockBtn({ onOpen(b.scr) }) { AppIcon(b.glyph, b.bg, b.fg, 46.dp) }
                else apps.firstOrNull { it.pkg == id }?.let { a -> DockBtn({ c.launch(a.pkg) }) { AppIcon(image = a.icon, size = 46.dp) } }
            }
            Box(Modifier.width(1.dp).height(30.dp).background(Color.White.copy(alpha = .15f)))
            if (bat >= 0) Text("${if (chg) "⚡" else "🔋"} $bat%", fontSize = 12.sp, color = Color(0xFFCFD3DA))
            Text(time, fontWeight = FontWeight.Bold)
            DockBtn(onQs) { AppIcon("⚙", Color(0xFF444444), size = 46.dp) }
        }
    }
}

@Composable
fun QuickSettings(modifier: Modifier, onOpen: (Scr) -> Unit) {
    val c = LocalContext.current; val act = c as? Activity
    var bright by remember { mutableFloatStateOf(act?.window?.attributes?.screenBrightness?.takeIf { it >= 0 } ?: 0.8f) }
    data class T(val e: String, val n: String, val on: Boolean, val f: () -> Unit)
    val tiles = listOf(
        T("📶", "Wi-Fi", false) { c.openSys(Settings.ACTION_WIFI_SETTINGS) },
        T("🦷", "Bluetooth", false) { c.openSys(Settings.ACTION_BLUETOOTH_SETTINGS) },
        T("🔊", "Som boot", AppState.sound) { AppState.sound = !AppState.sound; AppState.save() },
        T("🛡", "Guardian", AppState.guardianOn) { AppState.guardianOn = !AppState.guardianOn; AppState.save() },
        T("⚡", "Shizuku", ShizukuManager.ready) { onOpen(Scr.Shizuku) },
        T("☾", "Apresentação", false) { AppState.replay = true },
    )
    Glass(modifier.widthIn(max = 440.dp).fillMaxWidth(0.94f)) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(AppState.acc), contentAlignment = Alignment.Center) {
                    Text(AppState.name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(AppState.name, fontWeight = FontWeight.Bold)
                    Text(if (isQuest) "Meta Quest · EclipseDream" else "${Build.MANUFACTURER} ${Build.MODEL}", color = Mut, fontSize = 12.sp)
                }
                RoundBtn("⏻") { act?.finishAffinity() }
            }
            Spacer(Modifier.height(12.dp))
            tiles.chunked(3).forEach { row ->
                Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { t ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (t.on) AppState.acc else Color.White.copy(alpha = .07f)).clickable(onClick = t.f).padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) { Text(t.e, fontSize = 22.sp); Text(t.n, fontSize = 12.sp, color = if (t.on) Color.Black else Color.White) }
                    }
                }
            }
            SettingRow("☀ Brilho") {
                Slider(bright, { v -> bright = v; act?.window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = v } } }, valueRange = .05f..1f, modifier = Modifier.width(200.dp))
            }
            OutlinedButton(onClick = { onOpen(Scr.Settings) }, modifier = Modifier.fillMaxWidth()) { Text("Todas as configurações ›") }
        }
    }
}

@Composable
fun EnvBackground(env: String) {
    val acc = AppState.acc
    val stars = remember { List(160) { Offset(Random.nextFloat(), Random.nextFloat() * .75f) to Random.nextFloat() } }
    val inf = rememberInfiniteTransition(label = "env")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(120_000, easing = LinearEasing)), label = "rot")
    Canvas(Modifier.fillMaxSize()) {
        val c = Offset(size.width / 2, size.height * .36f); val R = size.maxDimension
        when (env) {
            "eclipse" -> {
                drawRect(Color(0xFF050200))
                rotate(rot, c) { for (i in 0 until 40 step 2) drawArc(Color(0xFF220700), i * 9f, 9f, true, Offset(c.x - R, c.y - R), Size(R * 2, R * 2)) }
                val g = size.minDimension * .35f
                drawCircle(Brush.radialGradient(listOf(acc.copy(alpha = .55f), Color.Transparent), c, g), g, c)
                val r = size.minDimension * .08f
                drawCircle(Color(0xFFFFD9A0), r * 1.06f, c); drawCircle(Color.Black, r, c)
                drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0xCC0A0300)), c, R * .8f))
            }
            "espaco" -> {
                drawRect(Color(0xFF02030A))
                val a = Offset(size.width * .3f, size.height * .3f); val b = Offset(size.width * .75f, size.height * .6f)
                drawCircle(Brush.radialGradient(listOf(Color(0x597828C8), Color.Transparent), a, R * .45f), R * .45f, a)
                drawCircle(Brush.radialGradient(listOf(Color(0x400078FF), Color.Transparent), b, R * .5f), R * .5f, b)
            }
            "aurora" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF020812), Color(0xFF0B3B2E))))
                drawRect(Brush.linearGradient(listOf(Color.Transparent, Color(0x4000FFAA), Color.Transparent), Offset(0f, size.height * .2f), Offset(size.width, size.height * .5f)))
                drawRect(Brush.linearGradient(listOf(Color.Transparent, Color(0x408C00FF), Color.Transparent), Offset(size.width, size.height * .25f), Offset(0f, size.height * .6f)))
            }
            "lago" -> drawRect(Brush.verticalGradient(0f to Color(0xFF1A1035), .3f to Color(0xFF5B2A6E), .47f to Color(0xFFFF7B54), .5f to Color(0xFFFFB26B), .503f to Color(0xFF2A3B5A), 1f to Color(0xFF0E1626)))
            else -> drawRect(Brush.radialGradient(listOf(Color(0xFF4A4F5A), Color(0xFF121318)), Offset(size.width / 2, size.height * .55f), R * .7f))
        }
        if (env == "espaco" || env == "aurora") stars.forEach { (p, a) -> drawCircle(Color.White.copy(alpha = a * .8f), 1.5f, Offset(p.x * size.width, p.y * size.height)) }
    }
}
